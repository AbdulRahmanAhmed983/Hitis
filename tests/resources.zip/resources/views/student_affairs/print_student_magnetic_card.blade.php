<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>card</title>
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Noto+Kufi+Arabic:wght@300;400&display=swap" rel="stylesheet">
</head>
<style>
    body{
        margin: 0;
        padding: 0;
        font-family: 'Noto Kufi Arabic', sans-serif;
    }
    .card{
        width:322px;
        height: 204px;
        position: relative;
    }
    .topnav{
        display: flex;
        justify-content: center;
        background-color: #144935;
    }
    .logo{
        height: 45px;
    }

    .flex{
            background-color: goldenrod;
            color: white;
            text-align: center;
            width: 100%;
            font-size: 9px;
            font-weight: 600;
    }

    .content{
        height: 115px;
        display: flex;
    }
    .left{
        width: 30%;
        text-align: center;
    }
    .left img{
        width: 71%;
        margin: auto;
        padding: 4px;

        }
    .center{
        width: 65%;
        padding: 5px;
        text-align: right;
    }
    .right{
        width: 4%;
    }
    .center div{
        font-size: 9px;
        font-weight: 600;
        line-height: 20px;
    }
    .footer{
        height: 30px;
        background-color: goldenrod;
        position: absolute;
        bottom: 0;
        width: 100%;
        border-top-left-radius: 50px;
        border-top-right-radius: 50px;
    }
    .footer-bottom{
            background-color:#144935;
            height: 20px;
            position: absolute;
            bottom: 0;
            width: 100%;
            border-top-left-radius: 50px;
            border-top-right-radius: 50px;
    }
    .footer-info{
        color: white;
        text-align: center;
        font-size: 9px;
        margin: 0;
    }

</style>
<body>
    @foreach($students as $student)
    <div class="card">
        <div class="header">
            <div class="topnav">
                <img class="logo" src="{{asset('images/logo.png')}}" alt="">
            </div>
            <div class="nav">
                <div class="flex">
                    <div class="flex-content ar">المعهد العالى للحاسب الآلى ونظم المعلومات </div>
                    <div class="flex-content en">High institute for computer & information system</div>
                </div>

            </div>
        </div>
        <div class="content">
            <div class="left">
                <img src="{{$student->photo}}"  alt="">
            </div>

            <div class="center">
                <div><span style="margin-left: 12px;">اسم الطالب </span><span id="name">{{Str::words($student->name, 7,'')}}</span></div>
                <div><span id="code"> {{$student->username}}</span><span style="margin-left: 12px;">كود الطالب </span></div>
                <div><span style="margin-left: 12px;"> الفرقة </span><span id="group"> {{$student->study_group}}</span></div>
               {{-- <div><span style="margin-left: 12px;">التخصص  </span><span id="specialize"> نظم المعلومات الادارية
                    باللغة {{($student->specialization=='عربي')? 'العربية':'الانجليزية'}}</span></div> --}}
               <div><span style="margin-left: 12px;">الشعبة  </span><span id="departments_id">
                     {{$student->departments_id}}</span></div>

            </div>
            <div class="right"></div>
        </div>
        <!--<div class="footer"></div>-->
        <div class="footer-bottom">
            <p class="footer-info">www.Aboukir-institute.edu.eg</p>
            <p style="color:white;font-size:7px;margin-top:-15px;margin-left:12%;">{{$year}}</p>
        </div>

    </div>
    @endforeach
    <script src="{{asset('assets/plugins/jquery/jquery.min.js')}}"></script>
    <script type="text/javascript">
        window.print();
        window.onafterprint = function () {
            window.location.replace("{{route('print.student.cards.index')}}");
        };
</body>
</html>
