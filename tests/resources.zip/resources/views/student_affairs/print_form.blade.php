@extends('layout.layout')
@section('title', $student['username'])
@section('styles')
@endsection
@section('content')
    <div class="row">
        <div class="col-12">
            <div class="card card-success">
                <div class="card-header d-flex">
                    <h2 class="col-6 text-dark my-auto">بيانات الطالب</h2>
                    <div class="col-2"></div>
                    <div class="col-4 float-right">
                        <img class="img-fluid" src="{{asset('images/logo.jpg')}}" alt="logo">
                    </div>
                </div>
                <div class="card-body">
                    <div class="form-group row mx-auto col-10">
                        <label class="col-2 control-label" for="name">إسم الطالب</label>
                        <div class="col-10">
                            <input type="text" value="{{$student['name']}}" readonly
                                   class="form-control" name="name" id="name">
                        </div>
                    </div>
                    <div class="form-group row mx-auto col-10">
                        <label class="col-2 control-label" for="username">كود الطالب</label>
                        <div class="col-10">
                            <input type="text" value="{{$student['username']}}" readonly
                                   class="form-control" name="username" id="username">
                        </div>
                    </div>
                    <div class="form-group row mx-auto col-10">
                        <label class="col-2 control-label" for="password">كلمة المرور</label>
                        <div class="col-10">
                            <input type="text" style="font-family: 'Lucida Sans Typewriter',serif" id="password"
                                   value="{{$student['password']}}" readonly class="form-control" name="password">
                        </div>
                    </div>
                    <div class="form-group row mx-auto col-10">
                        <label class="col-2 control-label" for="study_group">الفرقة الدراسية</label>
                        <div class="col-10">
                            <input type="text" value="{{$student['study_group']}}" readonly
                                   class="form-control" name="study_group" id="study_group">
                        </div>
                    </div>
                    <div class="form-group row mx-auto col-10">
                        <label class="col-2 control-label" for="specialization">التخصص</label>
                        <div class="col-10">
                            <input type="text" value="{{$student['specialization']}}" readonly
                                   class="form-control" name="specialization" id="specialization">
                        </div>
                    </div>
                    <div class="form-group row mx-auto col-10">
                        <label class="col-2 control-label" for="department">التخصص</label>
                        <div class="col-10">
                            <input type="text" value="{{$department}}" readonly
                                   class="form-control" name="departments_id" id="department">
                        </div>
                    </div>
                    <div class="form-group row mx-auto col-10">
                        <label class="col-2 control-label" for="studying_status">الحالة الدراسية</label>
                        <div class="col-10">
                            <input type="text" value="{{$student['studying_status']}}" readonly
                                   class="form-control" name="studying_status" id="studying_status">
                        </div>
                    </div>
                    <div class="form-group row mx-auto col-10">
                        <label class="col-2 control-label" for="date">التاريخ</label>
                        <div class="col-10">
                            <input type="text" value="{{$date}}" readonly
                                   class="form-control" name="date" id="date">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@section('scripts')
    <script>
        window.print();
        window.onbeforeprint = function () {
            $('nav.main-header').hide();
            $('aside.main-sidebar').hide();
            $('footer.main-footer').hide();
            $('.content-wrapper').removeClass('content-wrapper');
        };
        window.onafterprint = function () {
            window.location.replace("{{route('student.search')}}");
        };
    </script>
@endsection


