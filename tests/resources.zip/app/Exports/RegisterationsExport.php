<?php

namespace App\Exports;

use App\Models\Registeration;
use Maatwebsite\Excel\Concerns\FromCollection;

class RegisterationsExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return Registeration::all();
    }
}
